#　requests库：其实是对urllib的再次封装，
# 简化了一些处理流程

#要使用requests必须要导入这个三方库
#pip3 install requests

import requests
# url:目标url
# params:设置get请求携带的参数
#https://www.baidu.com/s?wd=西刺

# :param method:　请求方式
# :param url: 目标url
# :param params: 设置get请求携带的参数(放一个字典)
# :param data:设置post请求携带的参数(dict)
# :param headers: 请求的报头(User-Agent,cookie，．．．．)
# :param cookies: 设置cookie(可以是一个字典，也可以是一个cookiejar对像)
# :param files: 上传文件可以使用这个参数
# :param auth: 输入网页的验证（tuple类型的数据）
# :param timeout: 设置请求的超时时间
# :param proxies: 设置代理（一般是dict类型）
# :param verify: 默认是True，开启SSL验证，设置为False，忽略认证
# :param cert: 设置证书相关参数

params = {
    'wd':'西刺',
}

header = {
    'User-Agent':'Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/67.0.3396.99 Safari/537.36',
}

#response = requests.get('http://www.baidu.com/s?',params=params,headers=header)

#有些网站比如12306是自己定制的ＣＡ证书，不是从CA机构颁发的，我们需要忽略SSL认证
response = requests.get('https://www.12306.cn/',headers=header,verify=False)

# 获取页面源码，是一个字符串类型的数据
# print(response.text) 

#返回的是二进制类型的数据(要使用的化需要使用decode解码)
#print(response.content)
#获取当前响应的状态码
print(response.status_code)
# 获取当前请求的url地址
# print(response.url)
# ....





