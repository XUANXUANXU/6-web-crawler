import requests
from PIL import Image
#下载图片
#图片地址：https://upload-images.jianshu.io/upload_images/13157585-50b575574e64e7f1.jpg
url = 'https://upload-images.jianshu.io/upload_images/13157585-50b575574e64e7f1.jpg'

header = {
    'User-Agent':'Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/67.0.3396.99 Safari/537.36',
}

response = requests.get(url,headers=header)

with open('pricture.jpg','wb+') as file:
    file.write(response.content)

