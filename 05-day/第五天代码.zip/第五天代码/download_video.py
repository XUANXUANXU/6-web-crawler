import requests

url = 'https://jdvodoss.jcloudcache.com/vodtransgzp1251412368/7447398157012922116/v.f30.mp4'

header = {
    'User-Agent':'Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/67.0.3396.99 Safari/537.36',
}

response = requests.get(url,headers=header)

with open('video.mp4','wb+') as file:
    file.write(response.content)

print('下载完毕')