# 代理？
# 目的
# 协议分类
# 高匿程度分类

#如何使用代理？
#自定义opener
import urllib.request
import urllib.error as error

#自定义代理的处理器（ProxyHandler）
proxy_handle = urllib.request.ProxyHandler(
    {
        'https':'120.33.247.4:32395',
        'http':'123.157.67.30:34942',
    }
)

#自定义opener
#urllib.request.urlopen()
opener = urllib.request.build_opener(proxy_handle)

#设置一个header,来模拟浏览器访问　

req_header = {
    'User-Agent':'Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/67.0.3396.99 Safari/537.36',
}

#构造一个Request对象
req = urllib.request.Request('https://httpbin.org/get',headers=req_header)

try:
    #发起请求
    response = opener.open(req,timeout=5)
    print(response.status)
    print(response.read().decode())
except error.HTTPError as err:
    print(err,'代理不可用')
except error.URLError as err:
    print(err,'代理不可用')


