#使用requests发起post请求
import requests
# :param method:　请求方式
# :param url: 目标url
# :param params: 设置get请求携带的参数(放一个字典)
# :param data:设置post请求携带的参数(dict)
# :param headers: 请求的报头(User-Agent,cookie，．．．．)
# :param cookies: 设置cookie(可以是一个字典，也可以是一个cookiejar对像)
# :param files: 上传文件可以使用这个参数
# :param auth: 输入网页的验证（tuple类型的数据）
# :param timeout: 设置请求的超时时间
# :param proxies: 设置代理（一般是dict类型）
# :param verify: 默认是True，开启SSL验证，设置为False，忽略认证
# :param cert: 设置证书相关参数

#拉钩网为例：
url='https://www.lagou.com/jobs/positionAjax.json?city=%E5%8C%97%E4%BA%AC&needAddtionalResult=false'

form_data= {
    'first':'false',
    'pn':1,
    'kd':'iOS',
}

header = {
    'User-Agent':'Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/67.0.3396.99 Safari/537.36',
    'Referer':'https://www.lagou.com/jobs/list_iOS?labelWords=&fromSearch=true&suginput=',
}

response = requests.post(url,data=form_data,headers=header)

print(response.status_code)
print(type(response.text))
#　如果请求的数据是一个严格意义上的json字符串，我们可以使用
# response.json()将json字符串转换为python数据类型
print(type(response.json()))

if response.status_code == requests.codes.ok:
    print('请求成功')

#使用post请求上传一个文件

url = 'https://httpbin.org/post'



file = {'file':open('cookies.txt','r')}

response = requests.post(url,data=form_data,files=file)

print(response.status_code)
# print(response.text)
print(response.json())

#网页需要验证
response = requests.post('https://www.nxjsjcndcd.com/',data=form_data,auth=('username','password'))









