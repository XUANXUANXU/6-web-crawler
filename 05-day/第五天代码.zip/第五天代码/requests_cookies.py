# request关于cookies的使用
import requests
#百度为例子:

response = requests.get('http://www.baidu.com/')
print(response.status_code)
print(response.cookies)

print(response.cookies.items())
cookies = {}
for cookie in response.cookies.items():
    # print(type(cookie))
    # print(cookie)
    print(cookie[0]+'='+cookie[1])
    cookies[cookie[0]] = cookie[1]

print(cookies)

#使用cookies的方式
# 方式一：可以将cookies放在请求头中
# 方式二：直接可以使用请求的参数cookies:Dict or CookieJar object
#传了一个字典类型的cookies
response = requests.get('http://www.baidu.com',cookies=cookies)
print(response.status_code)

##CookieJar object
cookiesjar = requests.cookies.RequestsCookieJar()
for name,value in cookies.items():
    cookiesjar.set(name,value)
response = requests.get('http://www.baidu.com',cookies=cookiesjar)
print(response.status_code)











