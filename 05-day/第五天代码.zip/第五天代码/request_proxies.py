import requests
import requests.exceptions as exceptions

#代理，如何设置代理

# 使用requests设置代理：
proxies = {
    'https':'115.46.99.27:8123',
    'http':'183.62.22.220:3128',
}

try:
    response = requests.get('http://httpbin.org/get',proxies=proxies,timeout=10)
    print(response.status_code)
    print(response.text)
except exceptions.ConnectTimeout as err:
    print(err) 
