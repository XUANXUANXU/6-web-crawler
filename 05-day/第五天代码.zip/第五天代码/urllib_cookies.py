# cookies
# # http/https请求是无状态的请求，为了状态保持，有了cookies
# # 和session 
# # cookies:保存在客户端的
# # session:保存在服务端的

# #cookies的属性：name,value,domain,path,Amx-age,size,...
# #请求头中的cookie: name=value; name=value; ......

# #百度为例子

import urllib.request
from http import cookiejar

# #创建一个cookiejsar，来存储cookie,保存在内存中
# http_cookie = cookiejar.CookieJar()

# #创建一个handler来处理cookie
# processor = urllib.request.HTTPCookieProcessor(http_cookie)

# #自定义opener
# opener = urllib.request.build_opener(processor)

# #使用opener发起请求
# response = opener.open('https://www.baidu.com/')

# print(response.status)

# print(type(http_cookie))
# print(http_cookie)

# # for cookie in http_cookie:
# #     print(cookie.name+'='+cookie.value)

# #这个时候，再次使用opener发起请求，会携带cookie
# response = opener.open('https://www.baidu.com/s?wd=%E8%A5%BF%E5%88%BA')

#使用

# filename = 'cookies.txt'
# #创建一个MozillaCookieJar对象来存储cookie
# mz_cookiejar = cookiejar.MozillaCookieJar(filename)

# #创建一个HTTPCookieProcessor处理器，管理cookie
# processor = urllib.request.HTTPCookieProcessor(mz_cookiejar)

# #自定义opener 
# opener = urllib.request.build_opener(processor)

# #使用自定义的opener发起请求
# response = opener.open('https://www.baidu.com')

# #将获取的cookie保存在文件中
# mz_cookiejar.save()


#如何使用本地的cookie文件(加载本地的cookie文件，然后发起请求)
filename = 'cookies.txt'
mz_cookiejar = cookiejar.MozillaCookieJar()
mz_cookiejar.load(filename)
print(mz_cookiejar)

#创建一个HTTPCookieProcessor处理器，管理cookie
processor = urllib.request.HTTPCookieProcessor(mz_cookiejar)

#自定义opener 
opener = urllib.request.build_opener(processor)

#使用自定义的opener发起请求
response = opener.open('https://www.baidu.com')

#将自定义的opener设置为全局的opener
urllib.request.install_opener(opener)
# 设置自定义的opener为全局的opener之后，
# 我们自调用urllib.request.urlopen就
# 会使用自定义的opener

# 样例：






