#模拟知乎登录

from selenium import webdriver
import time
import json
#创建一个浏览器的驱动
driver = webdriver.Chrome(executable_path='/home/ljh/桌面/tool/chromedriver')

driver.get('https://www.zhihu.com/signup?next=%2F')

driver.find_element_by_css_selector('.SignContainer-switch span').click()

time.sleep(5)

driver.find_element_by_name('username').send_keys('15326245558')
driver.find_element_by_name('password').send_keys('q134679.')
driver.find_element_by_css_selector('.Button.SignFlow-submitButton.Button--primary.Button--blue').click()

cookies = driver.get_cookies()

cookie_dict = {}
for cookie in cookies:
    cookie_dict[cookie['name']] = cookie['value']

print(cookie_dict)

with open('cookie.json','w') as file:
    file.write(json.dumps(cookie_dict,ensure_ascii=False))

    
