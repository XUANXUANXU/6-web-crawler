
#第一页数据
https://xueqiu.com/v4/statuses/
public_timeline_by_category.json?
since_id=-1&max_id=-1&count=10
&category=-1
next_id:20308574
next_max_id:20308575

#第二页数据
https://xueqiu.com/v4/statuses/
public_timeline_by_category.json?
since_id=-1&max_id=20308575&count=15
&category=-1

# next_id
# :
# 20308559
# next_max_id
# :
# 20308560

#第二页数据
https://xueqiu.com/v4/statuses/
public_timeline_by_category.json?
since_id=-1&max_id=20308560&count=15
&category=-1


#沪深
https://xueqiu.com/v4/statuses/
public_timeline_by_category.json?
since_id=-1&max_id=-1&count=10&category=105