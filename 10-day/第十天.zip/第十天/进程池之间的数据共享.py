from multiprocessing import Pool,Manager,Queue
import os,time
#进程池之间实现数据共享一定要使用Manager模块下的数据类型
#https://docs.python.org/2/library/multiprocessing.html#managers

def write_data(queue):
    #注意这里方法中传过来的参数，不是一个元组
    print('写入数据')
    print('当前进程id'+str(os.getpid()))
    print(queue)
    print(type(queue))
    for i in range(0,50):
        print('插入数据'+str(i))
        queue.put(i)

def readData(queue):
    print(type(queue))
    print('获取数据')
    print('当前进程id'+str(os.getpid()))

    while not queue.empty():
        print(queue.get())

    

if __name__ == '__main__':

    print('主进程开启'+str(os.getpid()))

    # queue = Queue()
    queue = Manager().Queue()

    pool = Pool(4)
    #写入数据
    pool.apply_async(write_data,args=(queue,))

    time.sleep(3)

    #读取数据
    pool.apply_async(readData,args=(queue,))

    pool.close()
    pool.join()

    print('主进程结束'+str(os.getpid()))





