# 使用selenium来加载动态网页
# 首先要安装selenium：pip3 install selinium
# selinium自身不带浏览器驱动，我们要自己下载驱动

from selenium import webdriver
import time
#设置无头浏览器
# options = webdriver.ChromeOptions()
# options.set_headless()

#创建一个浏览器的驱动
# driver = webdriver.Chrome(
#     executable_path='/home/ljh/桌面/tool/chromedriver',
#     options=options
#     )

driver = webdriver.Chrome(
    executable_path='/home/ljh/桌面/tool/chromedriver',
    )

driver.get('http://www.baidu.com')

#保存屏幕的截图
# driver.save_screenshot('baidu.png')

#找到百度的输入框
# driver.find_element_by_id('kw').send_keys('美男子')
# #找到按钮，模拟点击
# driver.find_element_by_id('su').click()

# time.sleep(2)
#隐式等待
driver.implicitly_wait(5)

#添加显式等待
#设置循环等待
from selenium.webdriver.support.ui import WebDriverWait
#条件（根据条件寻找对应的节点）
from selenium.webdriver.support import expected_conditions as EC

driver_wait = WebDriverWait(driver,20)

driver_wait.until(
    # EC.element_to_be_selected(driver.find_element_by_id(''))
    EC.presence_of_element_located((By.ID, "myDynamicElement"))
)

# #通过连接的文本找对应的标签
# driver.find_element_by_link_text('下一页>').click()
# driver.find_element_by_class_name('n').click()

# time.sleep(5)

# #返回前页面
# driver.back()

# time.sleep(5)

# #前一页
# driver.forward()

# #关闭当前界面
# driver.close()

#通过page_source直接能够拿到经过浏览器渲染之后的页面数据
#print(driver.page_source)

# print(driver.get_cookies)

# 获取cookies值
# cookies = driver.get_cookies()

# for cookie in cookies:
#     print(cookie['name']+':'+cookie['value'])

# 拖拽和点击操作
from selenium.webdriver import ActionChains

element = driver.find_element_by_xpath('//div[@id="u1"]/a[1]')

#将鼠标移动到指定的节点
# ActionChains(driver).move_to_element(element).perform()
#将鼠标移动到指定的节点并且点击该节点(单击)
ActionChains(driver).move_to_element(element).click(element).perform()
#将鼠标移动到指定的节点并且点击该节点(双击击)
ActionChains(driver).move_to_element(element).double_click(element).perform()

##### 在 ac 位置右击
ActionChains(driver).move_to_element(action).context_click(action).perform()
##### 在 ac 位置左键单击hold住
ActionChains(driver).move_to_element(action).click_and_hold(action).perform()
##### 将 ac1 拖拽到 ac2 位置
ac1 = driver.find_element_by_id("su")
ac2 = driver.find_element_by_class_name('mnav')
ActionChains(driver).drag_and_drop(ac1,ac2).perform()

time.sleep(20)


# #退出浏览器
driver.quit()

#selenium的异常处理
from selenium.common.exceptions import TimeoutException,NoSuchElementException

#请求超时，异常处理
try:
    driver.get('https://github.com/')
except TimeoutError as err:
    print(err)

#找不到节点的异常处理
try:
    driver.find_element_by_id('sbcks')
except NoSuchElementException as err:
    print(err)


selenium的浏览器驱动也可以执行js语句
#####执行JS语句
js = "document.body.scrollTop=10000"
driver.execute_script(js)



