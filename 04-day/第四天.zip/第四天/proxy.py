# 1.代理？
# 代理的作用：在做爬虫的过程中，我们访问一个服务器，会携带本机的ＩＰ
# ，如果访问的频率过高（超过伐值），对方服务器可能会封掉你的IP,如果IP被
# 封，下次再访问，对方服务器不会给正确响应．这时候我们需要使用代理，通过代理
# 服务器访问对方服务器，来伪装我们的本机IP．

# 根据协议划分：
# FTP , HTTP , SSL/TSL ,SOCKS 

# 根据高匿程度划分：
# 高匿代理　，　普通匿名代理，　透明代理　，间谍代理

# 如果我们要使用免费的代理，那么要使用高匿代理

import urllib.request
import random
#使用urllib设置代理
#使用一个固定的ip
# proxy_handler = urllib.request.ProxyHandler(
#     {'https':'183.64.215.195:59418'}
# )

#构建一个简单的ip池.
proxy = [
    {'https':'183.64.215.195:59418'},
    {'https':'183.64.215.195:59418'},
    {'https':'183.64.215.195:59418'},
    {'https':'183.64.215.195:59418'},
    {'https':'183.64.215.195:59418'},
]

proxy_handler = urllib.request.ProxyHandler(
    random.choice(proxy)
)

# 创建opener对象
opener = urllib.request.build_opener(proxy_handler)

#不使用ip的一个对比
# https_handler = urllib.request.HTTPSHandler()
# # 创建opener对象
# opener = urllib.request.build_opener(https_handler)

form_data = {
    'data1':'values1',
}

form_data = urllib.parse.urlencode(form_data).encode('utf-8')

#构建一个请求对象
# req = urllib.request.Request('https://httpbin.org/post',data=form_data)

req = urllib.request.Request('https://httpbin.org/get')

#使用自定义的opener发起请求

response = opener.open(req)

print(response.read().decode())











