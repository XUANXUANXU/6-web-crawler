# 1.爬虫最基本的流程
# 　　　１．分析需求，寻找目标url，分析接口
# 　　　２．构造请求，模拟浏览器，发起请求，获取数据
# 　　　３．根据响应结果，通过正则等方式，获取目标数据
# 　　　　　　　a. 提取新的url,然后再次执行第２步
# 　　　４．将获取的数据保存（持久化）

# 通过urllib的最基本的爬虫

import urllib
# from http.client import HTTPResponse

#第一种：

# url, 目标url参数
# data=, 发起ｐｏｓｔ请求的时候使用这个参数
# timeout=,设置超时时间（发起请求，到获取响应的时间）
# context:,设置它，忽略SSL认证

#最基本的get请求
#get请求的参数，假如出现中，要转为url的编码格式
kw = {
    'kw':'中文网',
}
kw = urllib.parse.urlencode(kw)
response = urllib.request.urlopen('https://www.baidu.com',timeout=5)

#post请求
# 表单数据
formdata = {
    'data1':'value1',
    'data2':'value2',
    'data3':'value3',
}
#将表单数据转为url编码格式，切记最后要转为二进制数据（bytes）
formdata = urllib.parse.urlencode(formdata).encode('utf-8')
# 不需要添加headers,可以直接使用urlopen中的参数
response = urllib.request.urlopen('https://httpbin.org/post',data=formdata,timeout=5)


#请求需要添加请求头，先要构建一个Request对象
req_headers = {
    'User-Agent':'',
    'cookies':'',
    'Referer':'',
}
#User-Agent:用来模拟浏览器，如果不设置，默认是python3...
#cookies:用来模拟用户状态(里面存储的而用户信息)
#Referer：当前请求是从哪个页面过来的
req = urllib.request.Request('https://httpbin.org/post',data=formdata,headers=req_headers,method='POST')
#根据构建的Request对象，发起请求
response = urllib.request.urlopen(req)

#状态码：
# 200：表示成功
# 3xx：出重定向
# 4XX:　客户端错误
#    400：　请求错误
#    401:　需要用户认证
#    403:　用户无权限
#    404: 找不到网页
#    405: 请求方式不正确
#    407: 代理相关错误
#    408:　请求超时
# 500:服务器错误

#获取哪些数据
print(response.status)
print(response.getheaders())
print(response.getheader('Server'))
print(response.read().decode())
print(response.reason)
.....





　　　