#urllib:它是python自带的一个模块，我们可以使用这个模块去构造请求，
#模拟浏览器发送请求，获取响应
#request,error,parse

# request: 它是最基本的HTTP请求模块，可以用来模拟发送请求，
# 就像在浏览器中输入网址，然后敲击回车键一样，使用的时候只需
# 要给库方法传入相关的URL和相关的参数即可．

# error: 异常处理模块，如果出现请求错误，我们可以使用
# 这个模块来捕获异常，然后进行重试或者其他操作，保证程序不会意外终止．

# parse: 这是一个工具模块，提供了许多url的处理方法，
# 比如拆分,解析,合并等等.

#第一个get请求

import urllib.request 
import ssl
import http.client

#1.分析需求，确定目标url
url = 'https://www.baidu.com/'
#2.模拟浏览器发送请求，获取响应
#  url, 设置目标url
#  data=None, post请求的相关参数
#  timeout=,设置请求等待时间 
#  context=None, 设置是否忽略ssl认证

#设置是否忽略ssl认证

context = ssl._create_unverified_context()
response = urllib.request.urlopen(url,context=context)
print(response.read().decode())
print(type(response.read()))
print(response.status)
print(type(response))
print(response.getheaders())
print(response.getheader('Server'))
print(response.reason)


