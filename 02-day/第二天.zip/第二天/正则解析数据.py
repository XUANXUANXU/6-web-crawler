# 常用的正则表达式
# \d : 匹配数字(0-9)
# \D :匹配非数字
# \w :
# \W :
# \s :
# \S :
# . :
# *:
# +:
# ?:

# *?:非贪婪匹配
# .*?:尽可能少的匹配
# +?:
# ??:

# ():分组
# |:或
# ^:起始
# $:截止
# [0-9] -> \d
# [^0-9] -> \D
# ^A.* -> 必须以大A开头

import urllib.request as request
import re

#目标url
url = 'http://maoyan.com/board'

#构造请求对象
header = {
    'User-Agent':'Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/67.0.3396.99 Safari/537.36',
}

req = request.Request(url,headers=header)

response = request.urlopen(req)

html = response.read().decode('utf-8')

pattern=re.compile('<dd.*<img.*?alt="(.*?)".*?board-img.*?src="(.*?)".*?star">(.*?)</p>.*?releasetime">(.*?)</p>',re.S)

result = re.findall(pattern,html)

print(result)
# with open('page.html','w+') as file:
#     file.write(html)

# print(response.status)
# print(response.read().decode('utf-8'))
