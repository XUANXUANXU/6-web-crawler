import urllib.request as request
import urllib.parse as parse
import ssl
url = 'https://httpbin.org/post'

# header = {
#     'User-Agent':'Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/67.0.3396.99 Safari/537.36',
# }

from_data = {
    'name':'nckjdsbcdb',
    'age':18,
    'class':'1803',
}

#忽略未授权的ssl认证
context = ssl._create_unverified_context()

#使用了一个默认的ssl认证
context = ssl.create_default_context()

from_data = parse.urlencode(from_data).encode('utf-8')

req = request.Request(url,data=from_data)

response = request.urlopen(req)

print(response.read().decode('utf-8'))
