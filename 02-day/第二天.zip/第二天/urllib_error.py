import urllib.request as request
import urllib.error as error

url = 'https://www.douban.com/askcbsabckasvcksavcjhsavc/nscsncasb'

header = {
    'User-Agent':'Mozilla/5.0 (X11; Ubuntu; Linux x86_64; rv:61.0) Gecko/20100101 Firefox/61.0',
}

req  = request.Request(url,headers=header)

#单独判断URLError
# try:
#     response = request.urlopen(req,timeout=0.01)
#     print(response.status)
# except error.URLError as err:
#     print(err)

#单独判断HTTPError
# try:
#     response = request.urlopen(req)
#     print(response.status)
#     print(response.read().decode('utf-8'))
# except error.HTTPError as err:
#     print(err)

#优化的一个结果:先判断子类错误,在判断父类错误

try:
    response = request.urlopen(req)
    print(response.status)
    print(response.read().decode('utf-8'))
except error.HTTPError as err:
    print(err)
except error.URLError as err:
    print(err)
finally:
    print('请求成功')

#urllib.error.URLError: <urlopen error timed out>
#连接超时

print('snbckjdsbcl')


import urllib.parse as parse
#urljoin:url的拼接
baseurl = 'https://www.baidu.com/bsckbd/xsc'

sub_url = '/usbcdb/nckjdj'

sub_url = parse.urljoin(baseurl,sub_url)

print(sub_url)




