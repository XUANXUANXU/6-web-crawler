
#接口的作用,跟你你输入的文字,判断是什么类型的语言
#https://fanyi.baidu.com/langdetect

#将输入的内容转换为相应的结果
#https://fanyi.baidu.com/v2transapi

import urllib.request as request
import urllib.parse as parse
import json

kw = input('请输入要翻译的内容:')

#目标url
url1 = 'https://fanyi.baidu.com/langdetect'
#构造请求
header = {
    'User-Agent':'Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/67.0.3396.99 Safari/537.36',
}

from_data1 = {
    'query':kw,
} 

#1.将表单数据转换为url编码格式,2.再将数据编码为bytes类型
from_data1 = parse.urlencode(from_data1).encode('utf-8')
print(from_data1)

#构造请求对象
req = request.Request(url1,headers=header,data=from_data1)

#根据这个请求对象,发起请求
response = request.urlopen(req)

#将json字符串转换成python对象
dict = json.loads(response.read().decode('utf-8'))

print(response.status)

print(type(dict),dict)

#确定文字类型之后,翻译

url2 = 'https://fanyi.baidu.com/v2transapi'

t_from = dict['lan']
t_to = ''
if t_from == 'zh':
    t_to = 'en'
elif t_from == 'en':
    t_to = 'zh'



from_data2 = {
    'from':t_from,
    'to':t_to,
    'query':kw,
    'transtype':'translang',
    'simple_means_flag':3,
    'sign':'568888.806153',
    'token':'05a12b7834ef32d5218d8643f460c4c1'
}

header2 = {
    'User-Agent':'Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/67.0.3396.99 Safari/537.36',
    'Referer':'https://fanyi.baidu.com/translate?aldtype=16047&query=&keyfrom=baidu&smartresult=dict&lang=auto2zh',
    'Cookie':'BAIDUID=AA0F7D7E938825267961CCDB41A96CF8:FG=1; PSTM=1531142039; BDUSS=hQS3ZVWkROQk5uWDc3ZG9GLVF3a0hxVU1ualRhclQ3aE00Z1NmRWRWZGJEWEZiQVFBQUFBJCQAAAAAAAAAAAEAAABI2I2iwO6087TzNTU4AAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAFuASVtbgElbTD; BDORZ=B490B5EBF6F3CD402E515D22BCDA1598; REALTIME_TRANS_SWITCH=1; FANYI_WORD_SWITCH=1; HISTORY_SWITCH=1; SOUND_SPD_SWITCH=1; SOUND_PREFER_SWITCH=1; BDSFRCVID=0RLsJeC624HRs8R7uV-v-qt9dNgV_8JTH6aIGnutNYy7N2Y_GwcxEG0Pjf8g0KAbJNPXogKK0mOTHvbP; H_BDCLCKID_SF=tJ4tVIt2tIt3qR5gMJ5q-n3HKUrL5t_XbI6y3JjOHJOoDDkx0xv5y4LdjGKJBpjefNufLxLEbj6afKTgX4J4BTkp3-Aq5xcxajTJ2fTXJhuKof7j5PbWQfbQ0M6hqP-jW26aaqrxyn7JOpkxhfnxybKV0a62btt_fRPeoU5; PSINO=2; BIDUPSID=AA0F7D7E938825267961CCDB41A96CF8; BDRCVFR[feWj1Vr5u3D]=I67x6TjHwwYf0; H_PS_PSSID=1426_21105_20929; locale=zh; Hm_lvt_64ecd82404c51e03dc91cb9e8c025574=1536240012,1536240103,1536285918,1536300411; Hm_lpvt_64ecd82404c51e03dc91cb9e8c025574=1536300411; to_lang_often=%5B%7B%22value%22%3A%22zh%22%2C%22text%22%3A%22%u4E2D%u6587%22%7D%2C%7B%22value%22%3A%22en%22%2C%22text%22%3A%22%u82F1%u8BED%22%7D%5D; from_lang_often=%5B%7B%22value%22%3A%22en%22%2C%22text%22%3A%22%u82F1%u8BED%22%7D%2C%7B%22value%22%3A%22zh%22%2C%22text%22%3A%22%u4E2D%u6587%22%7D%5D',
}

from_data2 = parse.urlencode(from_data2).encode('utf-8')
print(from_data2)
req2 = request.Request(url2,data=from_data2,headers=header2)
response = request.urlopen(req2)
print(response.status)
print(response.read().decode('utf-8'))



