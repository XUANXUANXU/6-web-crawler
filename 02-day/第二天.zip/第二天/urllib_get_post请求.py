import urllib.request
import ssl
import http.client

#get请求
#寻找目标url
# url = 'http://www.baidu.com/s?wd=%E7%96%AF%E4%BA%BA%E9%99%A2'
#url = 'https://httpbin.org/'
#模拟浏览器，发起请求
# url:
# data:
# context:
# timeout:
# ssl_context = ssl._create_unverified_context()
# #发起请求，拿到响应结果
# response = urllib.request.urlopen(url,context=ssl_context)
# #状态吗
# print(response.status)
# #响应成功或失败的原因
# print(response.reason)
# #获取响应体（页面源码）
# print(response.read().decode('utf-8'))
# #获取响应头
# print(response.getheaders())
# print(type(response))
# # print(response.getheader(''))
# #..
# html = response.read().decode('utf-8')
# print(type(html))

# with open('page_1.html','w+') as file:

#     file.write(html)


#反爬虫第一步,创建带header的请求
#设置User-Agent:证明我是一个浏览器的操作
#在urllib.request.Request 构建一个请求对象
import urllib.request as request

#设置一个请求头
header = {
    'User-Agent':'Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/67.0.3396.99 Safari/537.36',
}

#构建一个请求对象
# url, 目标url
# data=None, post请求的表单数据
# headers={},　请求头信息(字典类型的数据)
# origin_req_host=None,(你服务器的ｉｐ：ｐｒｏｔ)
# method=None,（请求的方式）

req = request.Request(url='https://www.baidu.com',headers=header)

#设置context忽略ssl认证
ssl_context = ssl._create_unverified_context()

#发起请求
response = request.urlopen(req,context=ssl_context)

# print(response.status)

# 请求中出现中文,将中文转化为url编码
#parse模块下的urlencode方法，将我们的中文转换为url编码格式
import urllib.parse as parse
# wd='中非论坛'
word = {
    'wd':'中非论坛',
    'name':'某某某'
}
url_word = parse.urlencode(word)
# print(url_word)

#unquote将url编码格式转换为中文
word1=parse.unquote(url_word)
# print(word1)

#post请求
# data:只要传入ｄａｔａ参数，我们就认为是个post请求

#模拟豆瓣登录

#找到登录入口：
url = 'https://www.douban.com/accounts/login'

#构造post请求中的表单数据
from_data = {
    'source':'index_nav',
    'form_email':'18518753265',
    'form_password':'ljh123456',
    'captcha-solution':'potato',
    'captcha-id': 'dmFaZv68bjZfC8zDicTvh8zK:en',
    'login':'登录',
}

#2步
# 1.先将参数转换为url编码格式
# 2.将数据转换为bytes类型
from_data = parse.urlencode(from_data).encode('utf-8')

print(from_data)

req = request.Request(url,data=from_data,headers=header,method='POST')

#发起请求,
response = request.urlopen(req)

#打印响应状态吗和响应体
print(response.status)
print(response.read().decode())













