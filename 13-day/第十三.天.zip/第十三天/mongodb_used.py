import pymongo
from bson.objectid import ObjectId
# 1.连接数据库
mongo_conn = pymongo.MongoClient(host='localhost',port=27017)
#使用url的连接
# mongo_conn = pymongo.MongoClient('mongodb://localhost:27017/')
# #使用账号密码登录
# mongo_conn = pymongo.MongoClient('mongodb://user:pwd@localhost:27017/')

#切换到指定数据库
db = mongo_conn.class1803
# db = mongo_conn['class1803']
#获取数据库下的集合
students_col = db.students
students_col = db['students']

# 增
def add_data_to_db():
    document1 = {
        'name':'王喜钱',
        'info':'作业写了一半',
        'age':20,
    }
    document2 = {
        'name':'梁文琦',
        'info':'小伙子不错',
        'age':15,
    }
    document3 = {
        'name':'王宇飞',
        'info':'小伙子不错',
        'age':18,
    }
    #单条插入 -> 5ba9df8111575e7636a49485
    result = students_col.insert(document1)
    # result = students_col.insert_one(document1)
    #多条插入 -> [ObjectId('5ba9dfec11575e773b146826'), ObjectId('5ba9dfec11575e773b146827')]
    # result = students_col.insert([document2,document3])
    # result = students_col.insert_many([document2,document3])
    print(result)

# 改
def update_data_to_db():
    #update
    # result = students_col.update({'name':'王喜亮'},{'$set':{'info':'作业写完了'}})
    result = students_col.update({'name':'王喜亮'},{'info':'作业写完了,还有码？','name':'李斯','age':40})
    # result = students_col.update_one({'name':'王喜亮'},{'info':'作业写完了,还有码？','name':'李斯','age':40})
    # result = students_col.update_many({'name':'王喜亮'},{'info':'作业写完了,还有码？','name':'李斯','age':40})

    #save
    # result = students_col.save(
    #     {
    #         '_id':ObjectId("5ba9df8111575e7636a49485"),
    #         'name':'王喜亮',
    #         'age':25
    #     })
    #不存在自动添加
    result = students_col.save(
        {
            '_id':'jbcskbvlasbckasjbvkas',
            'name':'王喜钱',
            'age':25
        })
    print(result)

# 查
def find_data_to_db():
    #查询符合条件的文档
    # result = students_col.find({'name':'王喜钱'})
    #查询所有
    # result = students_col.find({}).skip(2).limit(1)
    #排序
    result = students_col.find({}).sort('age',1)
    result = students_col.find({}).sort([('age',1),('score',-1)])
    # print(result)
    print([i for i in result])
    #查询符合条件的第一条数据(返回的是一个字典)
    # result = students_col.find_one({'name':'王喜钱'})
    # print(result)

# 删
def delete_data_to_db():
    #删除符合条件的所有文档
    result = students_col.remove({'name':'王喜钱'})
    result = students_col.delete_many({'name':'王喜钱'})
    #multi设置为False,删除一条数据
    result = students_col.remove({'name':'王喜钱'},multi=False)
    result = students_col.delete_one({'name':'王喜钱'})
    print(result)


if __name__ == '__main__':
    # add_data_to_db()
    # update_data_to_db()
    # find_data_to_db()
    delete_data_to_db()
