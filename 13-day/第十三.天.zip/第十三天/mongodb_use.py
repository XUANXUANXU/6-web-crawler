1.创建用户必须是超级管理员（root）
2.创建用户
　　　首先切换到指定的数据库
　　　创建用户
　　　db.createUser({
       'user':,
       'pwd':,
       'roles':[{'role':'','db':''}]
     })
3.在etc下有一个mongod.conf　配置文件，
　我们需要开启安全认证的设置(重启)

4.mongo -u 用户名 -p 密码　--authenticationDatabase 数据库名称


#更新用户密码

#删除用户权限

#添加用户权限

#删除用户（两种方式）


#数据库的备份和
mongodump -h ip:port -d dbname -o 备份路径

mongodump -u 用户名 -p 密码 --authenticationDatabase 'dbname'　-h ip:port -d dbname -o 备份路径

#恢复
mongorestore -h ip:port -d dbname --dir 备份路径

mongorestore -u 用户名 -p 密码 --authenticationDatabase 'dbname' -h ip:port -d dbname --dir 备份路径

#数据的导出

mongoexport -d dbname -c collectionname -o path/文件名.json --type json 


mongoexport -d dbname -c collectionname -o path/文件名.csv --type csv -f '字段１,字段２'

#数据的导入：

mongoimport -d dbname -c collectionname　--file path/文件名.json --type json


mongoimport -d dbname -c collectionname　--file path/文件名.csv  --headerline --type csv


#主从副本集

一主一从


一主多从
